
def HMS_to_seconds(time):
    time = time.split(':')
    time = int(time[0])*3600 + int(time[1])*60 + int(time[2])

    return time

def calculate_elapsed_time(initial,current):
    return current-initial

def parse_log(file_name):
    parsed_lines = []
    start_time = 0

    with open(file_name) as f:
        content = f.readlines()

    print(content)

    for line in content:
        line = line.split(',')

        if not line[2] == "ardrone_086188":
            continue

        signal = line[5]
        time = line[0].split(' ')[1]

        if start_time == 0:
            start_time = HMS_to_seconds(time)
            time = 0
        else:
            time = calculate_elapsed_time(start_time,HMS_to_seconds(time))

        parsed_line = {"time": str(time), "signal": str(signal)}
        parsed_lines.append(parsed_line)

    return parsed_lines


def convert_to_graphStruct(parsed_lines):
    graph_lines = "["

    for line in parsed_lines:
        graph_lines +=  "[" + line["time"] + "," + line["signal"] + "],"

    graph_lines = graph_lines[:-1]
    graph_lines += "]"

    print(graph_lines)



if __name__ == '__main__':

    file_name = "/Users/alexisgallepe/Desktop/log.txt"
    parsed_lines = parse_log(file_name)
    convert_to_graphStruct(parsed_lines)